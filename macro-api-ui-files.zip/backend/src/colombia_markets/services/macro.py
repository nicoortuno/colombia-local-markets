"""Persist and query official macroeconomic observations."""

from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.dialects.postgresql import insert

from colombia_markets.db.models.macro import MacroObservation
from colombia_markets.db.session import SessionLocal


def upsert_macro_observations(records: list[dict[str, Any]]) -> int:
    """Idempotent on (series_key, observation_date); atomic per ingestion run."""
    if not records:
        return 0

    with SessionLocal() as session:
        for offset in range(0, len(records), 500):
            chunk = records[offset : offset + 500]
            statement = insert(MacroObservation).values(chunk)
            statement = statement.on_conflict_do_update(
                constraint="uq_macro_observation_series_date",
                set_={
                    key: getattr(statement.excluded, key)
                    for key in (
                        "series_name",
                        "value",
                        "source_series_id",
                        "periodicity_id",
                        "frequency",
                        "unit",
                        "source",
                        "provider",
                    )
                }
                | {"ingested_at": func.now()},
            )
            session.execute(statement)
        session.commit()
    return len(records)


def get_latest_macro_dates() -> dict[str, date]:
    """Return the latest stored observation date for every populated series."""
    with SessionLocal() as session:
        rows = session.execute(
            select(
                MacroObservation.series_key,
                func.max(MacroObservation.observation_date),
            ).group_by(MacroObservation.series_key)
        ).all()
    return {series_key: latest_date for series_key, latest_date in rows}


def get_macro_row_counts() -> dict[str, int]:
    """Convenience diagnostic used by ingestion output and manual validation."""
    with SessionLocal() as session:
        rows = session.execute(
            select(
                MacroObservation.series_key,
                func.count(MacroObservation.id),
            ).group_by(MacroObservation.series_key)
        ).all()
    return {series_key: int(count) for series_key, count in rows}
