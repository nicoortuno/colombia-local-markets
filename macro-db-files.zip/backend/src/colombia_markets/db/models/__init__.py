from colombia_markets.db.models.fx import FxDailyMarket
from colombia_markets.db.models.tes import TesDailyMarket

__all__ = ["FxDailyMarket", "TesDailyMarket"]
